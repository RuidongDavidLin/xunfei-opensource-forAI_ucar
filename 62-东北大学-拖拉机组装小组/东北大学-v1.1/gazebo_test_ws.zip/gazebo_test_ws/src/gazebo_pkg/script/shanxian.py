#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from nav_msgs.msg import Path, Odometry
from geometry_msgs.msg import PoseStamped, PoseArray, PoseWithCovarianceStamped, Point,Twist
from visualization_msgs.msg import Marker
import math
import numpy as np
from numpy import linalg as LA
from tf.transformations import euler_from_quaternion, quaternion_from_euler
import csv
import os


class following_path:    
    def __init__(self):
        self.current_pose = rospy.Subscriber('odom', Odometry, self.callback_read_current_position, queue_size=1)
        self.Pose = []
        self.path_pose = rospy.Subscriber('/move_base/TebLocalPlannerROS/local_plan', Path, self.callback_read_path, queue_size=1)
        self.path_info = []
        self.Goal = []
        self.path_pose2 = rospy.Subscriber('/move_base/GlobalPlanner/plan', Path, self.callback_read_path2, queue_size=1)
        self.path_info2 = []
        self.Goal2 = []
        self.NextPoint = []
        self.cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.last_ang =0
        self. last_vel = 0
        self.ttttt=0
    def callback_read_path(self, data):
        # Organize the pose message and only ask for (x,y) and orientation
        # Read the Real time pose message and load them into path_info
        self.path_info = []
        path_array = data.poses
        for path_pose in path_array:
            path_x = path_pose.pose.position.x
            path_y = path_pose.pose.position.y
            path_qx = path_pose.pose.orientation.x
            path_qy = path_pose.pose.orientation.y
            path_qz = path_pose.pose.orientation.z
            path_qw = path_pose.pose.orientation.w
            path_quaternion = (path_qx, path_qy, path_qz, path_qw)
            path_euler = euler_from_quaternion(path_quaternion)
            path_yaw = path_euler[2]
            self.path_info.append([float(path_x), float(path_y), float(path_yaw)])
        self.Goal = list(self.path_info[-1]) # Set the last pose of the local path as goal location 。the index is -1 means it is the last one，{倒数第一个，负几就是倒数第几个}

    def callback_read_path2(self, data):
        # Organize the pose message and only ask for (x,y) and orientation
        # Read the Real time pose message and load them into path_info
        self.path_info2 = []
        path_array = data.poses
        for path_pose in path_array:
            path_x = path_pose.pose.position.x
            path_y = path_pose.pose.position.y
            path_qx = path_pose.pose.orientation.x
            path_qy = path_pose.pose.orientation.y
            path_qz = path_pose.pose.orientation.z
            path_qw = path_pose.pose.orientation.w
            path_quaternion = (path_qx, path_qy, path_qz, path_qw)
            path_euler = euler_from_quaternion(path_quaternion)
            path_yaw = path_euler[2]
            self.path_info2.append([float(path_x), float(path_y), float(path_yaw)])
        self.Goal2 = list(self.path_info2[-1]) # Set the last pose of the global path as goal location

    def callback_read_current_position(self, data):
        VELOCITY = 0
        if not len(self.path_info) == 0:
            # Read the current pose of the car from particle filter
            if(self.ttttt==0):
                self.ttttt=self.ttttt+1
                os.system("gnome-terminal --tab -- rosservice call /gazebo/set_model_state '{model_state: { model_name: robot, pose: { position: { x: -0.2 , y: -5.3 , z: 0.83 }, orientation: {x: 0, y: 0, z: 0, w: 1 } }, twist: { linear: {x: 0.0, y: 0.0, z: 0.0 } , angular: { x: 0.0, y: 0.0, z: 0.0 } } , reference_frame: world } }'")


    
    # Computes the Euclidean distance between two 2D points p1 and p2
    def dist(self, p1, p2):
	    try:
		    return np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)
	    except:
		    return 0.5

    def find_angle(self, v1, v2):
        cos_ang = np.dot(v1, v2)#abcos
        sin_ang = LA.norm(np.cross(v1, v2)) #absin
        return np.arctan2(sin_ang, cos_ang) #向量叉乘除以向量点乘得到两个向量之间的角度
    def find_abs_angle(self, v1, v2):
        v1_model=LA.norm(v1)
        v2_model=LA.norm(v2)
        cos_ang = np.dot(v1, v2)/( v1_model*v2_model)#abcos
        return np.arccos(cos_ang) #向量叉乘除以向量点乘得到两个向量之间的角度
if __name__ == "__main__":

    rospy.init_node("pursuit_path")
    following_path()
    rospy.spin()
