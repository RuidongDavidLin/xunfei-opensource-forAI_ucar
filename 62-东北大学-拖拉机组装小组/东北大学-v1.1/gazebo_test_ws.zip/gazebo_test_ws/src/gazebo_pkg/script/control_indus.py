#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from nav_msgs.msg import Path, Odometry
from geometry_msgs.msg import PoseStamped, PoseArray, PoseWithCovarianceStamped, Point,Twist
from visualization_msgs.msg import Marker
import math
import numpy as np
from numpy import linalg as LA
from tf.transformations import euler_from_quaternion, quaternion_from_euler
import csv
import os


class following_path:    
    def __init__(self):
        self.current_pose = rospy.Subscriber('odom', Odometry, self.callback_read_current_position, queue_size=1)
        self.Pose = []
        self.path_pose = rospy.Subscriber('/move_base/TebLocalPlannerROS/local_plan', Path, self.callback_read_path, queue_size=1)
        self.path_info = []
        self.Goal = []
        self.NextPoint = []
        self.cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.last_velocity=0
        self.lookahead_k=0.5
        self.k1=0.4
        self.k2=5

        self.last_R = 0
        self.last_ang =0
        self. last_vel = 0

        self.init_markers_goal()     
        self.init_markers_current() 
        # self.points2circle()
    def init_markers_goal(self):  
        # Set up our waypoint markers  
        marker_scale = 0.15  
        marker_lifetime = 0 # 0 is forever  
        marker_ns = 'waypoints'  
        marker_id = 0  
        marker_color = {'r': 238.0, 'g': 118, 'b': 0.0, 'a': 1.0}  
          
        # Define a marker publisher.  
        self.marker_pub = rospy.Publisher('waypoint_markers', Marker)  
          
        # Initialize the marker points list.  
        self.markers = Marker()  
        self.markers.ns = marker_ns  
        self.markers.id = marker_id  
        self.markers.type = Marker.SPHERE_LIST  
        self.markers.action = Marker.ADD  
        self.markers.lifetime = rospy.Duration(marker_lifetime)  
        self.markers.scale.x = marker_scale  
        self.markers.scale.y = marker_scale  
        self.markers.color.r = marker_color['r']  
        self.markers.color.g = marker_color['g']  
        self.markers.color.b = marker_color['b']  
        self.markers.color.a = marker_color['a']  
          
        self.markers.header.frame_id = 'map'  
        self.markers.header.stamp = rospy.Time.now()  
        self.markers.points = list() 
    
    def init_markers_current(self):  
        # Set up our waypoint markers  
        marker_scale = 0.15  
        marker_lifetime = 0 # 0 is forever  
        marker_ns = 'current_pose_points'  
        marker_id = 1  
        marker_color = {'r': 128, 'g': 0, 'b': 128.0, 'a': 1.0}  
          
        # Define a marker publisher.  
        self.markers2_pub = rospy.Publisher('current_pose_point_markers', Marker)  
          
        # Initialize the marker points list.  
        self.markers2 = Marker()  
        self.markers2.ns = marker_ns  
        self.markers2.id = marker_id  
        self.markers2.type = Marker.SPHERE_LIST  
        self.markers2.action = Marker.ADD  
        self.markers2.lifetime = rospy.Duration(marker_lifetime)  
        self.markers2.scale.x = marker_scale  
        self.markers2.scale.y = marker_scale  
        self.markers2.color.r = marker_color['r']  
        self.markers2.color.g = marker_color['g']  
        self.markers2.color.b = marker_color['b']  
        self.markers2.color.a = marker_color['a']  
          
        self.markers2.header.frame_id = 'map'  
        self.markers2.header.stamp = rospy.Time.now()  
        self.markers2.points = list() 
        self.flag = 0

    def callback_read_path(self, data):
        # Organize the pose message and only ask for (x,y) and orientation
        # Read the Real time pose message and load them into path_info
        self.path_info = []
        path_array = data.poses
        for path_pose in path_array:
            path_x = path_pose.pose.position.x
            path_y = path_pose.pose.position.y
            path_qx = path_pose.pose.orientation.x
            path_qy = path_pose.pose.orientation.y
            path_qz = path_pose.pose.orientation.z
            path_qw = path_pose.pose.orientation.w
            path_quaternion = (path_qx, path_qy, path_qz, path_qw)
            path_euler = euler_from_quaternion(path_quaternion)
            path_yaw = path_euler[2]
            self.path_info.append([float(path_x), float(path_y), float(path_yaw)])
        self.Goal = list(self.path_info[-1]) # Set the last pose of the local path as goal location 。the index is -1 means it is the last one，{倒数第一个，负几就是倒数第几个}



    def callback_read_current_position(self, data):
        VELOCITY = 0.0
        angle = 0.0
        if not len(self.path_info) == 0:
            odom_vx=data.twist.twist.linear.x
            odom_w=data.twist.twist.angular.z
            this_time_r=odom_vx/odom_w

            # Read the current pose of the car from particle filter
            x = data.pose.pose.position.x#x是当前位置
            y = data.pose.pose.position.y
            qx = data.pose.pose.orientation.x
            qy = data.pose.pose.orientation.y
            qz = data.pose.pose.orientation.z
            qw = data.pose.pose.orientation.w
            quaternion = (qx,qy,qz,qw)

            # Convert the quaternion angle to eular angle
            euler = euler_from_quaternion(quaternion)
            yaw = euler[2]
            self.Pose = [float(x), float(y), float(yaw)]

            path_points_x = [float(point[0]) for point in self.path_info]#一条路径上所有点的x，
            path_points_y = [float(point[1]) for point in self.path_info]
            path_points_w = [float(point[2]) for point in self.path_info]

            LOOKAHEAD_DISTANCE =  0.5
            dist_array = np.zeros(len(path_points_x)) 
            distarray_minus_lookahead_dis=np.zeros(len(path_points_x)) 
            diff_angles = np.zeros(len(path_points_w)) 
            for i in range(len(path_points_x)):#算出路径上每一个点到x当前位置的distance和yaw
                dist_array[i] = self.dist((path_points_x[i], path_points_y[i]), (x,y))
                distarray_minus_lookahead_dis[i]=abs(dist_array[i]-LOOKAHEAD_DISTANCE)
                v1 = [path_points_x[i] - x, path_points_y[i] - y]
                v2 = [math.cos(yaw), math.sin(yaw)]
                diff_angles[i] = self.find_angle(v1,v2)
                if(np.cross(v1,v2)>0):
                    diff_angles[i] =- diff_angles[i]
            goal = np.argmin(distarray_minus_lookahead_dis) # Assume the closet point as the goal point at first ，给出水平方向最小值的下标，二维的也给展成一维的，找出最小的那个值的下标
            
            # the_first_one_in_tebpath_w=path_points_w[2]
            # v3=[math.cos(the_first_one_in_tebpath_w), math.sin(the_first_one_in_tebpath_w)]
            # yaw_the_first_one_in_tebpath_w= self.find_angle(v1,v3)
            # if(np.cross(v1,v3)>0):
            #     yaw_the_first_one_in_tebpath_w = -yaw_the_first_one_in_tebpath_w
         #  print("yaw_the_first_one_in_tebpath_w", yaw_the_first_one_in_tebpath_w)

            SEQENCE_BREAK =  1
            x2=path_points_x[1]
            y2=path_points_y[1]
            x3=path_points_x[2]
            y3=path_points_y[2]
            x4=path_points_x[3]
            y4=path_points_y[3]
            x5=path_points_x[4]
            y5=path_points_y[4]
            x6=path_points_x[5]
            y6=path_points_y[5]

            X_all = [x,x2,x3,x4,x5,x6]
            Y_all = [y,y2,y3,y4,y5,y6]

            x_average = np.mean(X_all)
            y_average = np.mean(Y_all)

            ui = X_all - x_average
            vi = Y_all - y_average

            Suuu = np.sum(ui**3)
            Svvv = np.sum(vi**3)
            Suu = np.sum(ui**2)
            Svv = np.sum(vi**2)
            Suv = np.sum(ui*vi)
            Suuv = np.sum(ui**2*vi)
            Suvv = np.sum(ui* vi**2)

            uc = (Suuv*Suv - Suuu*Svv - Suvv*Svv + Suv*Svvv)/(2*(Suv**2 - Suu*Svv))
            vc = (-Suu*Suuv + Suuu*Suv + Suv*Suvv - Suu*Svvv)/(2*(Suv**2 - Suu*Svv))

            xc = uc + x_average
            yc = vc + y_average

            R = np.sqrt(np.sum( (X_all - xc)**2 + (Y_all - yc)**2 )/6)
            # # print([xc,yc])
            # if (abs(xc - x) ==0):
            #     arrow = np.array([1,0])
            # else:
            #     arrow = np.array([ -(yc - y)/(xc - x),1])
            #     mode_len = np.sqrt(arrow[1]**2+arrow[0]**2)
            #     arrow = arrow/mode_len
            # print("---- ",arrow)
            # arr2 = np.array([x4-x,y4-y])
            # # print(arr2)
            # if(np.dot(arrow,arr2) <0):
            #     arrow = -1*arrow
            # #print(arrow)
            # v_1 = arrow
            # v_2 = [math.cos(yaw), math.sin(yaw)]
            # diff_arrow = self.find_angle(v_1,v_2)
            # if(np.cross(v_1,v_2)>0):
            #     diff_arrow = -diff_arrow



            angle_sign=diff_angles[goal]/abs(diff_angles[goal])
            if(R>10):
                VELOCITY = 1
                angle_abs=0
            elif (R>1.36): #v=1的情况下，Rmin＝1.36
                VELOCITY = 1
                angle_d=2
                angle_abs_goal=abs((odom_vx/R))*1.3161 + 0.0161#sign=+  最大1.36
                angle_abs_error=angle_abs_goal-abs(odom_w)
                angle_abs=angle_abs_goal+angle_d*angle_abs_error
         #      print("R>1.36")
            elif (R>0.14):
                VELOCITY = 0.4
                angle_d=1
                angle_abs_goal=abs((odom_vx/R))*1.7132 - 0.3263#sign=+  最大1.36
                angle_abs_error=angle_abs_goal-abs(odom_w)
                angle_abs=angle_abs_goal+angle_d*angle_abs_error
         #       print("R>0.14")
            else :
                VELOCITY = 0.1
                angle_d=1
                angle_abs_goal=1#sign=+  最大1.36
                angle_abs_error=angle_abs_goal-abs(odom_w)
                angle_abs=angle_abs_goal+angle_d*angle_abs_error
          #      print("R<0.14")
            angle=angle_sign*angle_abs
            # if(abs(diff_arrow)>0.5):
            #     print("ininin")
            #     VELOCITY=0
            #     angle=-0.1*diff_arrow
            move_cmd=Twist()
            move_cmd.linear.x = VELOCITY
            move_cmd.angular.z = angle
           
            if(x > -0.802 and x< 0.398) and(y > -5.896 and y < -4.696):
                move_cmd.linear.x = 0
                move_cmd.angular.z = 0
                self.flag = 1
        else:
            move_cmd=Twist()
            move_cmd.linear.x = 0.0
            move_cmd.angular.z = 0.0
        
        # print('v:',VELOCITY , 'angle:',angle)
        self.cmd_vel.publish(move_cmd)
        if(self.flag):
            exit(0)
    
    # Computes the Euclidean distance between two 2D points p1 and p2
    def dist(self, p1, p2):
	    try:
		    return np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)
	    except:
		    return 0.5

    # Compute the angle between car direction and goal direction
    def find_angle(self, v1, v2):
        cos_ang = np.dot(v1, v2)#abcos
        sin_ang = LA.norm(np.cross(v1, v2)) #absin
        return np.arctan2(sin_ang, cos_ang) #向量叉乘除以向量点乘得到两个向量之间的角度
    # def points2circle(p1, p2, p3):
        
if __name__ == "__main__":
    rospy.init_node("pursuit_path")
    following_path()
    rospy.spin()
