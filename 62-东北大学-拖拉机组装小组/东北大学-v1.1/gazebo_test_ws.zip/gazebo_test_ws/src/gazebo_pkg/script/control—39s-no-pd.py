#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from nav_msgs.msg import Path, Odometry
from geometry_msgs.msg import PoseStamped, PoseArray, PoseWithCovarianceStamped, Point,Twist
from visualization_msgs.msg import Marker
import math
import numpy as np
from numpy import linalg as LA
from tf.transformations import euler_from_quaternion, quaternion_from_euler
import csv
import os


class following_path:    
    def __init__(self):
        self.current_pose = rospy.Subscriber('odom', Odometry, self.callback_read_current_position, queue_size=1)
        self.Pose = []
        self.path_pose = rospy.Subscriber('/move_base/TebLocalPlannerROS/local_plan', Path, self.callback_read_path, queue_size=1)
        self.path_info = []
        self.Goal = []
        self.path_pose2 = rospy.Subscriber('/move_base/GlobalPlanner/plan', Path, self.callback_read_path2, queue_size=1)
        self.path_info2 = []
        self.Goal2 = []
        self.NextPoint = []
        self.cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.last_velocity=0
        self.lookahead_k=0.5
        self.k1=2.3
        self.k2=8
        self.init_markers_goal()     
        self.init_markers_current() 
    def init_markers_goal(self): 
        # Set up our waypoint markers  
        marker_scale = 0.15  
        marker_lifetime = 0 # 0 is forever  
        marker_ns = 'waypoints'  
        marker_id = 0  
        marker_color = {'r': 238.0, 'g': 118, 'b': 0.0, 'a': 1.0}  
          
        # Define a marker publisher.  
        self.marker_pub = rospy.Publisher('waypoint_markers', Marker)  
          
        # Initialize the marker points list.  
        self.markers = Marker()  
        self.markers.ns = marker_ns  
        self.markers.id = marker_id  
        self.markers.type = Marker.SPHERE_LIST  
        self.markers.action = Marker.ADD  
        self.markers.lifetime = rospy.Duration(marker_lifetime)  
        self.markers.scale.x = marker_scale  
        self.markers.scale.y = marker_scale  
        self.markers.color.r = marker_color['r']  
        self.markers.color.g = marker_color['g']  
        self.markers.color.b = marker_color['b']  
        self.markers.color.a = marker_color['a']  
          
        self.markers.header.frame_id = 'map'  
        self.markers.header.stamp = rospy.Time.now()  
        self.markers.points = list() 
    
    def init_markers_current(self):  
        # Set up our waypoint markers  
        marker_scale = 0.15  
        marker_lifetime = 0 # 0 is forever  
        marker_ns = 'current_pose_points'  
        marker_id = 1  
        marker_color = {'r': 128, 'g': 0, 'b': 128.0, 'a': 1.0}  
          
        # Define a marker publisher.  
        self.markers2_pub = rospy.Publisher('current_pose_point_markers', Marker)  
          
        # Initialize the marker points list.  
        self.markers2 = Marker()  
        self.markers2.ns = marker_ns  
        self.markers2.id = marker_id  
        self.markers2.type = Marker.SPHERE_LIST  
        self.markers2.action = Marker.ADD  
        self.markers2.lifetime = rospy.Duration(marker_lifetime)  
        self.markers2.scale.x = marker_scale  
        self.markers2.scale.y = marker_scale  
        self.markers2.color.r = marker_color['r']  
        self.markers2.color.g = marker_color['g']  
        self.markers2.color.b = marker_color['b']  
        self.markers2.color.a = marker_color['a']  
          
        self.markers2.header.frame_id = 'map'  
        self.markers2.header.stamp = rospy.Time.now()  
        self.markers2.points = list() 

    def callback_read_path(self, data):
        # Organize the pose message and only ask for (x,y) and orientation
        # Read the Real time pose message and load them into path_info
        self.path_info = []
        path_array = data.poses
        for path_pose in path_array:
            path_x = path_pose.pose.position.x
            path_y = path_pose.pose.position.y
            path_qx = path_pose.pose.orientation.x
            path_qy = path_pose.pose.orientation.y
            path_qz = path_pose.pose.orientation.z
            path_qw = path_pose.pose.orientation.w
            path_quaternion = (path_qx, path_qy, path_qz, path_qw)
            path_euler = euler_from_quaternion(path_quaternion)
            path_yaw = path_euler[2]
            self.path_info.append([float(path_x), float(path_y), float(path_yaw)])
        self.Goal = list(self.path_info[-1]) # Set the last pose of the local path as goal location 。the index is -1 means it is the last one，{倒数第一个，负几就是倒数第几个}

    def callback_read_path2(self, data):
        # Organize the pose message and only ask for (x,y) and orientation
        # Read the Real time pose message and load them into path_info
        self.path_info2 = []
        path_array = data.poses
        for path_pose in path_array:
            path_x = path_pose.pose.position.x
            path_y = path_pose.pose.position.y
            path_qx = path_pose.pose.orientation.x
            path_qy = path_pose.pose.orientation.y
            path_qz = path_pose.pose.orientation.z
            path_qw = path_pose.pose.orientation.w
            path_quaternion = (path_qx, path_qy, path_qz, path_qw)
            path_euler = euler_from_quaternion(path_quaternion)
            path_yaw = path_euler[2]
            self.path_info2.append([float(path_x), float(path_y), float(path_yaw)])
        self.Goal2 = list(self.path_info2[-1]) # Set the last pose of the global path as goal location

    def callback_read_current_position(self, data):
        VELOCITY = 0
        angle = 0
        if not len(self.path_info) == 0:
            # Read the current pose of the car from particle filter
            x = data.pose.pose.position.x#x是当前位置
            y = data.pose.pose.position.y
            qx = data.pose.pose.orientation.x
            qy = data.pose.pose.orientation.y
            qz = data.pose.pose.orientation.z
            qw = data.pose.pose.orientation.w
            quaternion = (qx,qy,qz,qw)
            # Convert the quaternion angle to eular angle
            euler = euler_from_quaternion(quaternion)
            yaw = euler[2]
            self.Pose = [float(x), float(y), float(yaw)]

            path_points_x = [float(point[0]) for point in self.path_info]#一条路径上所有点的x，
            path_points_y = [float(point[1]) for point in self.path_info]
            path_points_w = [float(point[2]) for point in self.path_info]

            LOOKAHEAD_DISTANCE =  0.3
            dist_array = np.zeros(len(path_points_x)) 
            distarray_minus_lookahead_dis=np.zeros(len(path_points_x)) 
            diff_angles = np.zeros(len(path_points_w)) 
            for i in range(len(path_points_x)):#算出路径上每一个点到x当前位置的distance和yaw
                dist_array[i] = self.dist((path_points_x[i], path_points_y[i]), (x,y))
                distarray_minus_lookahead_dis[i]=abs(dist_array[i]-LOOKAHEAD_DISTANCE)
                v1 = [path_points_x[i] - x, path_points_y[i] - y]
                v2 = [math.cos(yaw), math.sin(yaw)]
                diff_angles[i] = self.find_angle(v1,v2)
                if(np.cross(v1,v2)>0):
                    diff_angles[i] =- diff_angles[i]
                # p = Point()
                # p.x = path_points_x[i]
                # p.y = path_points_y[i]
                # p.z = 0
                # self.markers.points.append(p)
                # self.marker_pub.publish(self.markers)

                # print((np.arctan2(( path_points_y[i]-y),(derta_x))/3.14)*180)
                # print("yaw",yaw)
                # if(diff_angles[i]>3.14):
                #        print("yaw::::",yaw)
                #        print("            y::",y,    "path_points_y[i]",  path_points_y[i],"y-path_points_y[i]",y-path_points_y[i])
                #        print("            x::",x,    "path_points_x[i]",  path_points_x[i],"x-path_points_x[i]",x-path_points_x[i])     
                #        print(np.arctan2((y- path_points_y[i]),(x-path_points_x[i])))
                #        print('>>>>>>>>>>>>>>>>>>>>>>>>>')
                # #     diff_angles[i]=diff_angles[i]-3.14
                # if(diff_angles[i]<-3.14):
                #        print("yaw::::",yaw)
                #        print("            y::",y,    "path_points_y[i]",  path_points_y[i],"y-path_points_y[i]",y-path_points_y[i])
                #        print("            x::",x,    "path_points_x[i]",  path_points_x[i],"x-path_points_x[i]",x-path_points_x[i])     
                #        print(np.arctan2((y- path_points_y[i]),(x-path_points_x[i])))
                # #     #print(np.arctan2((y- path_points_y[i]),(x-path_points_x[i])))
                #        print('<<<<<<<<<<<<<<<<<<<<<<<<<')
                # #     diff_angles[i]=diff_angles[i]+3.14
            goal = np.argmin(distarray_minus_lookahead_dis) # Assume the closet point as the goal point at first ，给出水平方向最小值的下标，二维的也给展成一维的，找出最小的那个值的下标
            # print(self.find_angle( [path_points_x[goal] - x, path_points_y[goal] - y],[math.cos(yaw), math.sin(yaw)]))
            # print(diff_angles[goal])
            # print("-------------- ")
            # if(diff_angles[goal]>0.2):
            #     # print("yaw::::",yaw,"cos",math.cos(yaw),"sin",math.sin(yaw))
            #     print("            y::",y,    "path_points_y[i]",  path_points_y[goal],"path_points_y[i]-y",path_points_y[goal]-y)
            #     print("            x::",x,    "path_points_x[i]",  path_points_x[goal],"path_points_x[i]-X",path_points_x[goal]-x)     
                # print( [path_points_x[goal] - x, path_points_y[goal] - y])
                # print([math.cos(yaw), math.sin(yaw)])

            # print((np.arctan2(( path_points_y[goal]-y),(derta_x))/3.14)*180)

            # if((((np.arctan2(( path_points_y[i]-y),(derta_x))/3.14)*180)-yaw)>170):
            #         print((np.arctan2(( path_points_y[i]-y),(derta_x))/3.14)*180)
            #         p = Point()
            #         p.x = path_points_x[goal]
            #         p.y = path_points_y[goal]
            #         p.z = 0
            #         self.markers.points.append(p)
            #         self.marker_pub.publish(self.markers)
            #         print("path_points_x[goal]",path_points_x[goal])
            #         print("path_points_y[goal]",path_points_y[goal])
            #         q = Point()
            #         q.x = x
            #         q.y = y
            #         q.z = 0
            #         self.markers2.points.append(q)
            #         self.markers2_pub.publish(self.markers2)
            #         print("x",x)
            #         print("y",y)
            # goal_array = np.where((dist_array < (LOOKAHEAD_DISTANCE + 0.2)) & (dist_array > (LOOKAHEAD_DISTANCE - 0.2)))[0]
            # for id in goal_array:
            #     v1 = [path_points_x[id] - x, path_points_y[id] - y]
            #     v2 = [math.cos(yaw), math.sin(yaw)]
            #     diff_angle = self.find_angle(v1,v2)
            #     if abs(diff_angle) < np.pi/6: # Check if the one that is the cloest to the lookahead direction
            #         goal = id
            #         break

                        # draw the goal point (green)



            # print('distance',dist_array[goal])
            # print('angle',diff_angles[goal])
            VELOCITY=self.k1*dist_array[goal]
            angle=self.k2*diff_angles[goal]
            move_cmd=Twist()
            move_cmd.linear.x = VELOCITY
            self.last_velocity=VELOCITY
            move_cmd.angular.z = angle
        else:
            move_cmd=Twist()
            move_cmd.linear.x = 0.0
            move_cmd.angular.z = 0.0
        
        # print('v:',VELOCITY , 'angle:',angle)
        self.cmd_vel.publish(move_cmd)
    
    # Computes the Euclidean distance between two 2D points p1 and p2
    def dist(self, p1, p2):
	    try:
		    return np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)
	    except:
		    return 0.5

    # Compute the angle between car direction and goal direction
    def find_angle(self, v1, v2):
        cos_ang = np.dot(v1, v2)#abcos
        sin_ang = LA.norm(np.cross(v1, v2)) #absin
        return np.arctan2(sin_ang, cos_ang) #向量叉乘除以向量点乘得到两个向量之间的角度
    def find_abs_angle(self, v1, v2):
        v1_model=LA.norm(v1)
        v2_model=LA.norm(v2)
        cos_ang = np.dot(v1, v2)/( v1_model*v2_model)#abcos
        return np.arccos(cos_ang) #向量叉乘除以向量点乘得到两个向量之间的角度
if __name__ == "__main__":

    rospy.init_node("pursuit_path")
    following_path()
    rospy.spin()
