#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from nav_msgs.msg import Path, Odometry
from geometry_msgs.msg import PoseStamped, PoseArray, PoseWithCovarianceStamped, Point,Twist
from visualization_msgs.msg import Marker
import math
import numpy as np
from numpy import linalg as LA
from tf.transformations import euler_from_quaternion, quaternion_from_euler
import csv
import os


class following_path:    
    def __init__(self):
        self.current_pose = rospy.Subscriber('odom', Odometry, self.callback_read_current_position, queue_size=1)
        self.Pose = []
        self.path_pose = rospy.Subscriber('/move_base/TebLocalPlannerROS/local_plan', Path, self.callback_read_path, queue_size=1)
        self.path_info = []
        self.Goal = []
        self.teb_cmdvel= rospy.Subscriber('movebase_cmd_vel', Twist, self.teb_cmdvel_callback, queue_size=1)
        self.teb_cmd_x=0
        self.teb_cmd_w=0
        self.NextPoint = []
        self.cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.last_ang =0
        self. last_vel = 0
    def teb_cmdvel_callback(self,data):
        self.teb_cmd_x=data.linear.x
        self.teb_cmd_w=data.angular.z

    def callback_read_path(self, data):
        # Organize the pose message and only ask for (x,y) and orientation
        # Read the Real time pose message and load them into path_info
        self.path_info = []
        path_array = data.poses
        for path_pose in path_array:
            path_x = path_pose.pose.position.x
            path_y = path_pose.pose.position.y
            path_qx = path_pose.pose.orientation.x
            path_qy = path_pose.pose.orientation.y
            path_qz = path_pose.pose.orientation.z
            path_qw = path_pose.pose.orientation.w
            path_quaternion = (path_qx, path_qy, path_qz, path_qw)
            path_euler = euler_from_quaternion(path_quaternion)
            path_yaw = path_euler[2]
            self.path_info.append([float(path_x), float(path_y), float(path_yaw)])
        self.Goal = list(self.path_info[-1]) # Set the last pose of the local path as goal location 。the index is -1 means it is the last one，{倒数第一个，负几就是倒数第几个}


    def callback_read_current_position(self, data):
        VELOCITY = 0
        angle = 0
        # Read the current pose of the car from particle filter
        x = data.pose.pose.position.x#x是当前位置
        y = data.pose.pose.position.y
        qx = data.pose.pose.orientation.x
        qy = data.pose.pose.orientation.y
        qz = data.pose.pose.orientation.z
        qw = data.pose.pose.orientation.w
        quaternion = (qx,qy,qz,qw)
        # Convert the quaternion angle to eular angle
        euler = euler_from_quaternion(quaternion)
        yaw = euler[2]
        self.Pose = [float(x), float(y), float(yaw)]
        if (x>-0.81 and x<2)and(y>-6.65 and y <-4.9):
                move_cmd=Twist()
                move_cmd.linear.x = self.teb_cmd_x*1.25
                print("move_cmd.linear.x",move_cmd.linear.x)
                move_cmd.angular.z = self.teb_cmd_w*1.05
                print("move_cmd.angular.z ",move_cmd.angular.z)
                print("tebtebteb")
        else:
            if not len(self.path_info) == 0:
                path_points_x = [float(point[0]) for point in self.path_info]#一条路径上所有点的x，
                path_points_y = [float(point[1]) for point in self.path_info]
                path_points_w = [float(point[2]) for point in self.path_info]

                LOOKAHEAD_DISTANCE =  0.4
                dist_array = np.zeros(len(path_points_x)) 
                distarray_minus_lookahead_dis=np.zeros(len(path_points_x)) 
                diff_angles = np.zeros(len(path_points_w)) 
                for i in range(len(path_points_x)):#算出路径上每一个点到x当前位置的distance和yaw
                    dist_array[i] = self.dist((path_points_x[i], path_points_y[i]), (x,y))
                    distarray_minus_lookahead_dis[i]=abs(dist_array[i]-LOOKAHEAD_DISTANCE)
                    v1 = [path_points_x[i] - x, path_points_y[i] - y]
                    v2 = [math.cos(yaw), math.sin(yaw)]
                    diff_angles[i] = self.find_angle(v1,v2)
                    if(np.cross(v1,v2)>0):
                        diff_angles[i] =- diff_angles[i]
                goal = np.argmin(distarray_minus_lookahead_dis) # Assume the closet point as the goal point at first ，给出水平方向最小值的下标，二维的也给展成一维的，找出最小的那个值的下标
            
                SEQENCE_BREAK =  1
                x2=path_points_x[1]
                y2=path_points_y[1]
                x3=path_points_x[2]
                y3=path_points_y[2]
                x4=path_points_x[3]
                y4=path_points_y[3]
                x5=path_points_x[4]
                y5=path_points_y[4]
                x6=path_points_x[5]
                y6=path_points_y[5]

                X_all = [x,x2,x3,x4,x5,x6]
                Y_all = [y,y2,y3,y4,y5,y6]

                x_average = np.mean(X_all)
                y_average = np.mean(Y_all)

                ui = X_all - x_average
                vi = Y_all - y_average

                Suuu = np.sum(ui**3)
                Svvv = np.sum(vi**3)
                Suu = np.sum(ui**2)
                Svv = np.sum(vi**2)
                Suv = np.sum(ui*vi)
                Suuv = np.sum(ui**2*vi)
                Suvv = np.sum(ui* vi**2)

                uc = (Suuv*Suv - Suuu*Svv - Suvv*Svv + Suv*Svvv)/(2*(Suv**2 - Suu*Svv))
                vc = (-Suu*Suuv + Suuu*Suv + Suv*Suvv - Suu*Svvv)/(2*(Suv**2 - Suu*Svv))

                xc = uc + x_average
                yc = vc + y_average

                R = np.sqrt(np.sum( (X_all - xc)**2 + (Y_all - yc)**2 )/6)   

                ang_d = diff_angles[goal] - self.last_ang
                self.last_ang = diff_angles[goal]            

                angle=9*diff_angles[goal]+ 30* ang_d
                if(abs(angle)>6):
                    angle=6*abs(angle)/angle

                print("R---------------------------------",R)
                if(0.5<R<7):
                    VELOCITY=1.12-0.2*abs(angle)
                    # VELOCITY=1.2-0.3*abs(angle)
                    print("1111111")
                elif(0.3<R<0.5):
                    VELOCITY=0.9-0.15*abs(angle)
                    print("222222222222")
                elif(R<0.3):
                    VELOCITY=0.5-0.14*abs(angle)
                    print("33333333333")
                else:
                    VELOCITY=1.5-0.11*abs(angle)
                    print("444444444444")
                # if(10<R<20):
                #     VELOCITY=1.2-0.35*abs(angle)
                #     print("1111111111")
                # elif(0.5<R<10):
                #     VELOCITY=1.2-0.22*abs(angle)
                #     # VELOCITY=1.2-0.3*abs(angle)
                #     print("22222222222")
                # elif(0.3<R<0.5):
                #     VELOCITY=0.95-0.17*abs(angle)
                #     print("333333333")
                # elif(R<0.3):
                #     VELOCITY=0.7-0.18*abs(angle)
                #     print("444444444444")
                # else:
                #     VELOCITY=1.57-0.38*abs(angle)
                #     print("555555555555")
                move_cmd=Twist()
                move_cmd.linear.x = VELOCITY
                move_cmd.angular.z = angle
                # if (x>-0.802 and x<0.398)and(y>-5.896 and y <-4.696):          
                if (x>-0.81 and x<0.47)and(y>-6 and y <-4.25):
                    move_cmd.linear.x=0
                    move_cmd.angular.z=0
                    print("end")
            else:
                move_cmd=Twist()
                move_cmd.linear.x = 0.0
                move_cmd.angular.z = 0.0
        
        # print('v:',VELOCITY , 'angle:',angle)
        self.cmd_vel.publish(move_cmd)
    
    # Computes the Euclidean distance between two 2D points p1 and p2
    def dist(self, p1, p2):
	    try:
		    return np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)
	    except:
		    return 0.5

    def find_angle(self, v1, v2):
        cos_ang = np.dot(v1, v2)#abcos
        sin_ang = LA.norm(np.cross(v1, v2)) #absin
        return np.arctan2(sin_ang, cos_ang) #向量叉乘除以向量点乘得到两个向量之间的角度
    def find_abs_angle(self, v1, v2):
        v1_model=LA.norm(v1)
        v2_model=LA.norm(v2)
        cos_ang = np.dot(v1, v2)/( v1_model*v2_model)#abcos
        return np.arccos(cos_ang) #向量叉乘除以向量点乘得到两个向量之间的角度
if __name__ == "__main__":

    rospy.init_node("pursuit_path")
    following_path()
    rospy.spin()
