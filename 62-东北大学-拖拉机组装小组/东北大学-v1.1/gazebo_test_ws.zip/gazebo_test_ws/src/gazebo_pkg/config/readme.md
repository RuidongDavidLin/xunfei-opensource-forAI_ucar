调了一版比较凶的参数 直线速度1.5 转弯速度1 我直接把加速度约束都给成0了  定位很差劲 尤其转弯的时候 但是能苟完 单规划的路径直挺挺的 虽然可以原地转弯 但是转速大了雷达匹配不好定位容易飘 

 
 max_vel_x: 2
 max_vel_x_backwards: 0.3
 max_vel_theta: 1
 acc_lim_x: 2
 acc_lim_theta: 2

 weight_max_vel_x: 1
 weight_max_vel_theta: 0.5
 weight_acc_lim_x: 1
 weight_acc_lim_theta: 1
 weight_kinematics_nh: 1000
 weight_kinematics_forward_drive: 50

角速度0.5

改为 acc_lim_theta: 3：角速度1
改为  weight_max_vel_theta:1 转弯角速度0.5是真的  但是好像转弯比较晚？
改为  weight_acc_lim_theta: 0 转弯角速度1 
改为  weight_acc_lim_theta: 0  weight_acc_lim_x: 0 转弯角速度1 直线线速度1.9
改为  max_vel_x: 1.5 weight_acc_lim_theta: 0  weight_acc_lim_x: 0 转弯角速度1 直线线速度1.5

