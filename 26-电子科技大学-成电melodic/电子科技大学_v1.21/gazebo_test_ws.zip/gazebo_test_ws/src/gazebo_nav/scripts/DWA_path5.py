#!/usr/bin/env python
import rospy
from std_msgs.msg import Header
from nav_msgs.msg import Path, Odometry
from geometry_msgs.msg import PoseStamped, PoseArray, Twist, Point, PointStamped
import math
import numpy as np
from numpy import linalg as LA
from tf.transformations import euler_from_quaternion, quaternion_from_euler
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import os
import time

"""  state list
First
Common
S_rot
Behind
Low_vel
Reach
"""
r1_ = 0.2
r2_ = 1.7
co_d = 0.2
co_k = 0.25
maxlv = 1.0
maxv = 0.87
minv = 0.45
Kr = 1.382

max_angle = 1.5
LOOKAHEAD_DISTANCE = 0.4

xishu = np.array([[r2_ ** 2, 1],
                  [r1_ ** 2, 1]])
sudu = np.array([maxv, minv])
cans = np.matmul(np.linalg.inv(xishu), sudu)


class following_path:
    def __init__(self):
        self.current_pose = rospy.Subscriber('/odom', Odometry, self.callback_read_current_position,
                                             queue_size=1)
        self.Pose = []
        self.velo = 0
        self.path_pose1 = rospy.Subscriber('/move_base/DWAPlannerROS/global_plan', Path, self.callback_read_path1,
                                          queue_size=1)

        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        self.path_info = []
        self.Goal = np.array([0.2, -5.33])
        self.navigation_input = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.Pointpub = rospy.Publisher('/r3_p', PointStamped, queue_size=1)

        self.Mode = 'First'
        self.count_time_flag = 0
        self.time_start = 0
        self.ggoal = MoveBaseGoal()
        self.g_th = 0
        self.goal_list = np.array([[2.4, -6.4, -2.9],
                                   [0.2, -5.33, 2.65]])

    def callback_read_path2(self, data):
        """
        Organize the pose message and only ask for (x,y) and orientation
        Read the Real time pose message and load them into path_info
        """
        if self.g_th >= 2:
            self.path_info = []
            path_array = data.poses
            for path_pose in path_array:
                path_x = path_pose.pose.position.x
                path_y = path_pose.pose.position.y
                path_qx = path_pose.pose.orientation.x
                path_qy = path_pose.pose.orientation.y
                path_qz = path_pose.pose.orientation.z
                path_qw = path_pose.pose.orientation.w
                path_quaternion = (path_qx, path_qy, path_qz, path_qw)
                path_euler = euler_from_quaternion(path_quaternion)
                path_yaw = path_euler[2]
                self.path_info.append([float(path_x), float(path_y), float(path_yaw)])
            print('/move_base/GlobalPlanner/plan')

        else:
            pass

    def callback_read_path1(self, data):
        """
        Organize the pose message and only ask for (x,y) and orientation
        Read the Real time pose message and load them into path_info
        """
        if self.g_th < 2:
            self.path_info = []
            path_array = data.poses
            for path_pose in path_array:
                path_x = path_pose.pose.position.x
                path_y = path_pose.pose.position.y
                path_qx = path_pose.pose.orientation.x
                path_qy = path_pose.pose.orientation.y
                path_qz = path_pose.pose.orientation.z
                path_qw = path_pose.pose.orientation.w
                path_quaternion = (path_qx, path_qy, path_qz, path_qw)
                path_euler = euler_from_quaternion(path_quaternion)
                path_yaw = path_euler[2]
                self.path_info.append([float(path_x), float(path_y), float(path_yaw)])
            print('/move_base/DWAPlannerROS/global_plan')
        else:
            pass

    def callback_read_current_position(self, data):
        x = data.pose.pose.position.x
        y = data.pose.pose.position.y
        quaternion = (data.pose.pose.orientation.x,
                      data.pose.pose.orientation.y,
                      data.pose.pose.orientation.z,
                      data.pose.pose.orientation.w)
        euler = euler_from_quaternion(quaternion)
        yaw = euler[2]
        self.velo = data.twist.twist.linear.x
        self.Pose = [float(x), float(y), float(yaw)]
        self.send_goals()
        VELOCITY = 0.0
        angular = 0.0

        if self.Pose[0] < 4.9 and self.Pose[1] > -0.5:
            self.Mode = 'First'

        elif self.Mode == 'First' and self.Pose[0] >= 4.9:
            self.Mode = 'Common'

        elif self.Mode == 'Common' and self.Pose[0] > 2 and self.Pose[1] < -3.7:
            self.Mode = 'S_rot'

        elif self.Mode == 'S_rot' and self.Pose[0] > 4.5 and self.Pose[1] < -4.3:
            self.Mode = 'Behind'

        elif self.Mode == 'Behind' and self.dist(self.Goal, self.Pose) < 1.4 and self.Pose[1] < -4.7:
            self.Mode = 'Low_vel'

        elif self.Mode == 'Low_vel' and self.dist(self.Goal, self.Pose) < 0.5:
            self.Mode = 'Reach'
            self.path_info = []
            self.Pose = []
            print('time cost: ', time.time() - self.time_start, 's')
            while 1:
                vel_msg = Twist()
                vel_msg.linear.x = 0.0
                vel_msg.linear.y = 0.0
                vel_msg.linear.z = 0.0
                vel_msg.angular.x = 0.0
                vel_msg.angular.y = 0.0
                vel_msg.angular.z = 0.0
                self.navigation_input.publish(vel_msg)

        if not len(self.path_info) == 0:

            # Read the path information to path_point list
            path_points_x = [float(point[0]) for point in self.path_info]
            path_points_y = [float(point[1]) for point in self.path_info]
            path_points_w = [float(point[2]) for point in self.path_info]

            # 2. Find the path point closest to the vehichle tat is >= 1 lookahead distance from vehicle's current
            # location.
            dist_array = np.zeros(len(path_points_x))

            for i in range(len(path_points_x)):
                dist_array[i] = self.dist((path_points_x[i], path_points_y[i]), (x, y))

            goal = np.argmin(dist_array)  # Assume the closet point as the goal point at first
            goal_array = \
                np.where((dist_array < (LOOKAHEAD_DISTANCE + 0.3)) & (dist_array > (LOOKAHEAD_DISTANCE - 0.3)))[0]

            for id in goal_array:
                v1 = [path_points_x[id] - x, path_points_y[id] - y]
                v2 = [math.cos(yaw), math.sin(yaw)]
                diff_angle = self.find_angle(v1, v2)
                if abs(diff_angle) < np.pi / 4:  # Check if the one that is the cloest to the lookahead direction
                    goal = id
                    break

            L = dist_array[goal]

            # 3. Transform the goal point to vehicle coordinates.
            pnear = np.array([path_points_x[goal], path_points_y[goal]])  # goal place
            pv = np.array([math.cos(path_points_w[goal]), math.sin(path_points_w[goal])])

            pnear, pv = self.road_control(pnear, pv)

            v2 = np.array([math.cos(yaw), math.sin(yaw)]) * self.velo
            pla = np.array([x, y]) + 0.03 * v2  # now place

            # goal vol vector
            vo = Kr * (pnear - pla) + pv

            vo_ang = np.angle(complex(vo[0], vo[1]))
            # print('vo_ang:', vo_ang)

            d_angle = 1.05 * (vo_ang - yaw)  # Find the turning angle
            if d_angle > np.pi:
                d_angle = d_angle - 2 * np.pi
            if d_angle < -np.pi:
                d_angle = d_angle + 2 * np.pi

            angle = np.clip(d_angle, -max_angle, max_angle)
            angle = (0 if abs(angle) < 0.01 else angle)

            VELOCITY = self.speed_control(pla, self.path_info)
            angular = VELOCITY * 2 * math.sin(angle) / L  # Find the wheel turning angular

        else:
            print('bu xin')

        vel_msg = self.cmd_vel_pub(VELOCITY, angular)
        self.navigation_input.publish(vel_msg)

    def cmd_vel_pub(self, velocity, angular):
        vel_msg = Twist()
        vel_msg.linear.x = 0.0
        vel_msg.linear.y = 0.0
        vel_msg.linear.z = 0.0
        vel_msg.angular.x = 0.0
        vel_msg.angular.y = 0.0
        vel_msg.angular.z = 0.0

        if self.Mode == 'Reach':
            pass
        else:
            vel_msg.linear.x = velocity
            vel_msg.angular.z = angular

        facke1 = np.array([4.9, -0.6])
        if self.dist(self.Pose, facke1) < 0.55 and self.Pose[1] > -0.5:
            vel_msg.angular.z = angular - 1.8
            print('fc0 catch', angular)

        if 4.8 < self.Pose[0] < 5.3 and -1.5 < self.Pose[1] < -0.5:
            vel_msg.angular.z = angular + 2.5
            print('fc1 catch', angular)

        if 1.4 < self.Pose[0] < 3 and -1.02 < self.Pose[1] < -0.5:
            vel_msg.angular.z = angular + 1.0
            print('fc2 catch', angular)
        if self.Mode == 'Behind' and 1.8 < self.Pose[0] < 2.9:
            vel_msg.angular.z -= 10
            print('fc2 catch', angular)
        if self.dist(self.Pose, self.Goal) < 1.3:
            vel_msg.angular.z += (62 + 10*self.Pose[1])
            print('fc2 catch', angular)
        else:
            pass

        return vel_msg

    def dist(self, p1, p2):
        """
        Computes the Euclidean distance between two 2D points p1 and p2
        """
        try:
            return np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)
        except:
            return 0.5

    def find_angle(self, v1, v2):
        """
        Compute the angle between car direction and goal direction
        """
        cos_ang = np.dot(v1, v2)
        sin_ang = LA.norm(np.cross(v1, v2))
        return np.arctan2(sin_ang, cos_ang)
        # Control the speed of the car within the speed limit

    def speed_control(self, pla, path_info=None):
        Velocity = 0.8
        if self.Mode == 'Reach':
            Velocity = 0.0
        elif self.Mode == 'Low_vel':
            Velocity = max(min(0.9, 0.6*abs(self.velo)), 0.4)
        elif self.Mode in ('Common', 'S_rot', 'Behind'):
            if path_info:
                dss = 1
                for pin in path_info:
                    pinx = [pin[0], pin[1]]
                    if co_k * self.velo < self.dist(pla, pinx) <= co_k * self.velo + co_d and dss == 1:
                        s1 = pinx
                        dss += 1
                    elif co_k * self.velo + co_d < self.dist(pla, pinx) <= co_k * self.velo + 2 * co_d and dss == 2:
                        s2 = pinx
                        dss += 1
                    elif self.dist(pla, pinx) >= co_k * self.velo + 2 * co_d and dss == 3:
                        s3 = pinx
                        header = Header(seq=0, stamp=rospy.Time.now(), frame_id="map")
                        pot_msg = Point(x=s3[0], y=s3[1], z=0)
                        Potst_msg = PointStamped(header=header, point=pot_msg)
                        self.Pointpub.publish(Potst_msg)
                        dss += 1
                        break

                if dss == 4:
                    dis1 = self.dist(s1, s2)
                    dis2 = self.dist(s1, s3)
                    dis3 = self.dist(s2, s3)
                    radius = (dis1 * dis2 * dis3) / np.sqrt((dis1 + dis2 - dis3) *
                                                            (dis1 - dis2 + dis3) * (dis2 + dis3 - dis1) * (
                                                                    dis1 + dis2 + dis3) + 0.000001)

                    if self.Mode == 'Common':
                        if 2.4 < self.Pose[0]:
                            if radius > r2_:
                                Velocity = maxlv
                            elif r1_ < radius <= r2_:
                                Velocity = cans[0] * radius ** 2 + cans[1]
                            
                            else:
                                Velocity = 0.8
                        else:
                            if radius > r2_:
                                Velocity = maxlv + 0.1
                            elif r1_ < radius <= r2_:
                                Velocity = cans[0] * radius ** 2 + cans[1] + 0.05
                            
                            else:
                                Velocity = 0.6
                    elif self.Mode == 'S_rot':
                        if radius > r2_:
                            Velocity = maxlv + 0.1
                        elif r1_ < radius <= r2_:
                            Velocity = cans[0] * radius ** 2 + cans[1] + 0.05
                            print('Velocity:', Velocity)
                        else:
                            Velocity = 0.6
                    elif self.Mode == 'Behind':
                        print('radius:', radius)
                        if 2.2 < self.Pose[0] < 3.4:
                            if radius > r2_:
                                Velocity = maxlv + 0.8
                            elif r1_ < radius <= r2_:
                                Velocity = cans[0] * radius ** 2 + cans[1] + 0.35
                            
                            else:
                                Velocity = 0.8
                        else:
                            if radius > r2_:
                                Velocity = maxlv + 1.6
                            elif r1_ < radius <= r2_:
                                Velocity = cans[0] * radius ** 2 + cans[1] + 0.5
                            
                            else:
                                Velocity = 0.8

        elif self.Mode == 'First':
            if self.Pose[0] < 2.3:
                Velocity = 2.9
            else:
                Velocity = 0.75
        else:
            pass

        return Velocity

    def road_control(self, pnear, pv):
        if self.Mode == 'First' and self.Pose[0] > 0.5 and self.Pose[1] > 0:
            pnear = pnear - pnear[0]*np.array([0, 0.033])
        elif self.Mode == 'Common':
            pp_1 = np.array([5, -0.7])
            pp_2 = np.array([1.3, -1.6])
            pp_3 = np.array([1.3, -2.5])
            pp_4 = np.array([1.3, - 3.7])
            if self.dist(pnear, pp_1) < 0.7 and pnear[0] > 4.9:
                pnear = pnear - np.array([0.68, 0.03])
                # pnear = pnear - np.array([0, 0.03])
                print('pp_1')
            if 1.5 < pnear[0] < 5 and -1.6 < pnear[1] < -0.5:
                pnear = pnear - np.array([0, 0.12])
                if pnear[1] < -1.3:
                    pnear[1] = -1.3
            if self.dist(pnear, pp_2) < 0.5 and pnear[0] < 1.3:
                pnear = pnear + np.array([0.15, -0.02])
                print('pp_2')
            if self.dist(pnear, pp_3) < 0.5 and pnear[0] > 1.3:
                pnear = pnear - np.array([0.18, -0.08])
                print('pp_3')
            if self.dist(pnear, pp_4) < 0.5 and pnear[0] < 1.3:
                pnear = pnear + np.array([0.12, 0])
                print('pp_4')
        else:
            pass
        return pnear, pv

    def send_goals(self):
        if self.g_th == 0 and self.Mode in ('S_rot', 'Behind'):
            self.ggoal.target_pose.header.frame_id = 'map'
            self.ggoal.target_pose.pose.position.x = self.goal_list[self.g_th][0]
            self.ggoal.target_pose.pose.position.y = self.goal_list[self.g_th][1]
            self.ggoal.target_pose.pose.position.z = 0
            quaternion = quaternion_from_euler(0, 0, self.goal_list[self.g_th][2])
            self.ggoal.target_pose.pose.orientation.x = quaternion[0]
            self.ggoal.target_pose.pose.orientation.y = quaternion[1]
            self.ggoal.target_pose.pose.orientation.z = quaternion[2]
            self.ggoal.target_pose.pose.orientation.w = quaternion[3]
            self.client.send_goal(self.ggoal)
            self.g_th += 1
        if self.Pose[0] < 3.6 and self.g_th == 1 and self.Mode == 'Behind':
            self.ggoal.target_pose.header.frame_id = 'map'
            self.ggoal.target_pose.pose.position.x = self.goal_list[self.g_th][0]
            self.ggoal.target_pose.pose.position.y = self.goal_list[self.g_th][1]
            self.ggoal.target_pose.pose.position.z = 0
            quaternion = quaternion_from_euler(0, 0, self.goal_list[self.g_th][2])
            self.ggoal.target_pose.pose.orientation.x = quaternion[0]
            self.ggoal.target_pose.pose.orientation.y = quaternion[1]
            self.ggoal.target_pose.pose.orientation.z = quaternion[2]
            self.ggoal.target_pose.pose.orientation.w = quaternion[3]
            self.client.send_goal(self.ggoal)
            self.g_th += 1
            self.path_pose2 = rospy.Subscriber('/move_base/GlobalPlanner/plan', Path, self.callback_read_path2,
                                          queue_size=1)
            del(self.path_pose1)

if __name__ == "__main__":
    rospy.init_node("pursuit_path")
    following_path()
    rospy.spin()