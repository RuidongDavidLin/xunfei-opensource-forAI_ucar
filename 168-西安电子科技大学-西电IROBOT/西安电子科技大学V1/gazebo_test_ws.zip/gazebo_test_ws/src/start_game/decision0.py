#!/usr/bin/env python
# -*- coding: utf-8 -*-
#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from std_msgs.msg import String
from sensor_msgs.msg import Image
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge, CvBridgeError
import cv2
import atexit
import numpy as np

# 拐点1: (5.35, 0)
# 障碍2: (3.42,-1.08)
# 障碍2.1:(3.03, -0.99)
# 拐点2: (1.165, -1.01)
# 拐点2_1:(0.95, -1.70)
# 拐点3: (1.78, -2.54)
# 拐点4: (0.85, -3.75)   (1.2, -4.8)
# 拐点5: (5.39, -3.21)
class decision():
    def __init__(self):
        rospy.init_node("decision", anonymous=True)
        self.distance = 0
        # 速度
        # rospy.Subscriber("/")
        # 图像
        self.forward_distance = 0
        # rospy.Subscriber("/scan", LaserScan, self.LidarCallback)
        # rospy.Publisher("/cmd_vel")
        self.pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        # 初始路径
        self.data1 = Twist()
        self.data1.linear.x = 3
        # 第二条
        self.data2 = Twist()
        # self.data2

    def run(self):
        rospy.Subscriber("/odom", Odometry, self.PosCallback)
        rospy.Subscriber("/info_cmd", Twist, self.CmdCallback)
        rospy.spin()

    def PosCallback(self, data):
        self.position = data.pose.pose.position


    def CmdCallback(self, data):
        if self.position.y > -0.1:
            if self.position.x < 2.3:
                self.pub.publish(self.data1)
            else:
                data.angular.z = data.angular.z*2
                # data.linear.x = data.linear.x*
                self.pub.publish(data)
        # 第二条线
        elif self.position.y > -1:
            if 2.4 < self.position.x < 3:
                data.linear.x = data.linear.x*2.4
                self.pub.publish(data)
            else:
                self.pub.publish(data)
        # M 拐弯的开始
        elif self.position.y > -2.3:
            if self.position.x < 2.9:
                data.linear.x = data.linear.x*1.3
                data.angular.z = data.angular.z*1.35
                self.pub.publish(data)
            else:
                self.pub.publish(data)
        # M 中段附近
        elif self.position.y > -2.6:
            data.angular.z = data.angular.z*1.6
            self.pub.publish(data)
        elif -2.6 > self.position.y > -3.5 and self.position.x < 3.2:
            data.linear.x = data.linear.x+0.11
            data.angular.z = data.linear.z * 7-0.6
            self.pub.publish(data)
        elif -3.7 < self.position.y < -3.4 and self.position.x < 1:
            # data.linear.x = data.linear.x*1.2
            # data.angular.z = data.angular.z-0.4
            self.pub.publish(data)
        elif -4.6 < self.position.y < -4 and 2 < self.position.x < 3.9:
            data.linear.x = data.linear.x*1.5+0.2
            data.angular.z = data.angular.z+0.4
            self.pub.publish(data)
        # elif self.position.y :
        elif -4.8 < self.position.y < -3.5 and 3.9 < self.position.x < 5:
            data.angular.z = data.angular.z - 0.6
            data.linear.x = data.linear.x*1.1
            self.pub.publish(data)
        elif  self.position.y < -4.7 and self.position.x < 4.7:
            data.angular.z = data.angular.z *1.1
            data.linear.x = data.linear.x * 2
            self.pub.publish(data)
        elif (self.position.y+5.27)^2+(self.position.x+0.23)^2 < 0.2:
            data.linear.x = 0
            data.angular.z = 0
            self.pub.publish(data)
        else:
            self.pub.publish(data)



decide = decision()
decide.run()
