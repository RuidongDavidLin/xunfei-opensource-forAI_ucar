#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import rospy
import tf
import dynamic_reconfigure.client
import numpy as np

				# [第一弯，W弯道,直道,减速]
acc_lim_x=                      [1,1,1.2,4]
acc_lim_theta=                  [4.5,4.8,3.5,3.5]
max_vel_x=                      [1.0,1.1,1.6,0.02]
max_vel_theta=    		[10,10,8,8]
weight_kinematics_forward_drive=[400,400,1000,1000]
weight_optimaltime=		[190,180,100,100] #190
weight_obstacle=		[20,20,48,48] 
weight_viapoint=		[30,30,1,1]   
inflation_dist=			[0.1,0.1,0.4,0.4] 
weight_kinematics_turning_radius=[1,50,1,1]

threshold=0.3
current_spin=0

def callback(config):
     rospy.loginfo("Config set to max_vel_x: {max_vel_x}, acc_lim_theta: {acc_lim_theta}".format(**config))

def isin(trans,state):
	# rospy.loginfo("({},{})".format(trans[0],trans[1]))
	dist=np.sqrt((trans[0]-state[0])**2+(trans[1]-state[1])**2)
	# rospy.loginfo("{}".format(dist))
	if dist<threshold:
		return True
	else:
		return False
 
if __name__ == "__main__":
	rospy.init_node("dynamic_client")
     	listener = tf.TransformListener()
     	client = dynamic_reconfigure.client.Client("/move_base/TebLocalPlannerROS", timeout=30, config_callback=callback)
 
	# client.update_configuration({"max_vel_x":max_vel_x[1], "acc_lim_theta":acc_lim_theta[1]})
	r = rospy.Rate(5)
	
	state1=[1.781,-1.138] #开始U型弯
	state2=[2.207,-4.098] #结束U型弯2.307
     	state3=[4.104,-0.081] #开始第一弯
     	state4=[2.081,-1.084] #结束第一弯
	state5=[4.889,-3.126]
	state6=[4.8,-4.6]

	pos0=[3.504,-0.081] #开始第一弯
	pos1=[2.081,-1.084] #结束第一弯
	pos2=[5.779,-3.786] #结束U型弯
	pos3=[0.733,-5.733]  #终点前

	state=np.array([pos0,pos1,pos2,pos3])
	n=len(state)
	listener.waitForTransform('/map','/base_footprint',rospy.Time(0),rospy.Duration(6.0))
	while not rospy.is_shutdown():
		(trans,rot) = listener.lookupTransform('/map','/base_footprint',rospy.Time(0))
	
		if current_spin<n and isin(trans, state[current_spin]):	
			client.update_configuration({"acc_lim_x":acc_lim_x[current_spin], "acc_lim_theta":acc_lim_theta[current_spin],
					             "max_vel_x":max_vel_x[current_spin], "max_vel_theta":max_vel_theta[current_spin],
						     "weight_kinematics_forward_drive":weight_kinematics_forward_drive[current_spin],
						     "weight_optimaltime":weight_optimaltime[current_spin],"weight_obstacle":weight_obstacle[current_spin],
						     "weight_viapoint":weight_viapoint[current_spin],"inflation_dist":inflation_dist[current_spin],
						     "weight_kinematics_turning_radius":weight_kinematics_turning_radius[current_spin] })
			current_spin=current_spin+1
			rospy.loginfo("Update successfully:{}".format(current_spin))

	

	r.sleep()



